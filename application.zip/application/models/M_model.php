<?php

/**
 * Created by PhpStorm.
 * User: Hp Spectre Xt
 * Date: 9/15/2017
 * Time: 4:23 AM
 */
class Users_model extends CI_Model
{
    public function get($user_id = null)
    {
        if ($user_id == null) {
            $query = $this->db->get('tbl_users');
        } elseif (is_array($user_id)) {
            $query = $this->db->get_where('tbl_users', $user_id);
        }
        return $query->result_array();
    }

    public function create($data)
    {
        $this->db->insert('tbl_users', $data);
        return $this->db->insert_id();
    }

    public function update($data, $user_id)
    {
        $this->db->update('tbl_users', $data, [
            'user_id' => $user_id
        ]);
        return $this->db->affected_rows();
    }

    public function delete($user_id)
    {

        $this->db->delete('tbl_users', [
            'user_id' => $user_id
        ]);
        return $this->db->affected_rows();
    }
}