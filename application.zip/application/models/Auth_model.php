<?php
class Auth_model extends CI_Model
{
    public function get($user = null)
    {
        $this->db->select('*');
        $this->db->from('tbl_users');
        $this->db->where([
            'username'=>$user['username'],
            'password'=>$user['password']
        ]);
        $query = $this->db->get();
        return $query->result_array();
    }
    public function create($data)
    {
        $this->db->insert('tbl_users', $data);
        return $this->db->insert_id();
    }
    public function update($data, $user_id)
    {
        $this->db->update('tbl_users', $data, [
            'user_id' => $user_id
        ]);
        echo '1234';
        return $this->db->affected_rows();
    }
    public function delete($user_id)
    {
        $this->db->update('tbl_users', [
            'user_id' => $user_id
        ]);
        return $this->db->affected_rows();
    }
/*    function upload_image($title,$image){
        $data = array(
            'title' => $title,
            'file_name' => $image,
        );
        $this->db->insert('tbl_images',$data);
        return $this->db->insert_id();
    }*/
    public function upload_image($data)
    {
        $this->db->insert('tbl_images', $data);
        return $this->db->insert_id();
    }
    public function upload_video($data)
    {
        $this->db->insert('tbl_videos', $data);
        return $this->db->insert_id();
    }
    public function show_images()
    {
        $images = $this->db->get('tbl_images')->result_array();
        return $images;
    }
    public function show_videos()
    {
        $videos = $this->db->get('tbl_videos')->result_array();
        return $videos;
    }
}