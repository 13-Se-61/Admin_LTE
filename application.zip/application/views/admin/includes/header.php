<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?= $title ?></title>
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <link rel="stylesheet" href="<?php echo base_url() ?>/public/admin/plugins/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo base_url() ?>/public/admin/plugins/bootstrap/dist/css/bootstrap.css">
    <link rel="stylesheet" href="<?php echo base_url() ?>/public/admin/plugins/bootstrap/dist/css/bootstrap-theme.css">
    <link rel="stylesheet" href="<?php echo base_url() ?>/public/admin/plugins/bootstrap/dist/css/bootstrap-theme.min.css">

    <link rel="stylesheet" href="<?php echo base_url() ?>/public/admin/plugins/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?php echo base_url() ?>/public/admin/plugins/Ionicons/css/ionicons.min.css">
    <link rel="stylesheet" href="<?php echo base_url() ?>/public/admin/plugins/datatables.net-bs/css/dataTables.bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo base_url() ?>/public/admin/plugins/bootstrap-daterangepicker/daterangepicker.css">
    <link rel="stylesheet" href="<?php echo base_url() ?>/public/admin/dist/css/AdminLTE.min.css">
    <link rel="stylesheet" href="<?php echo base_url() ?>/public/admin/dist/css/skins/_all-skins.min.css">
    <link rel="stylesheet" href="<?php echo base_url() ?>/public/admin/plugins/toastr/toastr.min.css">
    <link rel="stylesheet" href="<?php echo base_url() ?>/public/admin/plugins/dropzone/dropzone.css">
    <link rel="stylesheet" href="<?php echo base_url() ?>/public/admin/plugins/dropzone/basic.css">
    <link rel="stylesheet" href="<?php echo base_url() ?>/public/admin/plugins/dropify-master/dist/css/demo.css">
    <link rel="stylesheet" href="<?php echo base_url() ?>/public/admin/plugins/dropify-master/dist/css/dropify.css">
    <link rel="stylesheet" href="<?php echo base_url() ?>/public/admin/plugins/dropify-master/dist/css/dropify.min.css">
    <link rel="stylesheet" href="<?php echo base_url() ?>/public/admin/plugins/select2/dist/css/select2.min.css">
    <link href="https://fonts.googleapis.com/css?family=Orbitron" rel="stylesheet">
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <script src="Downloads/dropzone.js"></script>
    <script src="https://cdnjs.cloudflare.com /ajax/libs/dropzone/5.5.1/dropzone.js"></script>
    <![endif]-->
    <style>
        [class^='select2'] {
            border-radius: 0px !important;
        }
        .no-select {
            -webkit-touch-callout: none; /* iOS Safari */
            -webkit-user-select: none; /* Safari */
            -khtml-user-select: none; /* Konqueror HTML */
            -moz-user-select: none; /* Firefox */
            -ms-user-select: none; /* Internet Explorer/Edge */
            user-select: none;
            /* Non-prefixed version, currently
                                             supported by Chrome and Opera */
        }
        table > th, td {
            white-space: nowrap;
        }
        form > legend {
            font-weight: bold;
        }
        .form-group-sm > label {
            font-size: 12px;
        }
    </style>
    <link rel="stylesheet"
          href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
</head>
<body class="hold-transition skin-blue fixed sidebar-collapse sidebar-mini ">
<div class="wrapper">
    <header class="main-header">
        <a href="" class="logo">
            <span class="logo-mini"><b>AL</b></span>
            <span class="logo-lg"><b>Admin</b>LTE</span>
        </a>
        <nav class="navbar navbar-static-top">
            <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </a>
            <div class="navbar-custom-menu">
                <ul class="nav navbar-nav">
                    <!--<li class="dropdown messages-menu">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                            <i class="fa fa-envelope-o"></i>
                            <span class="label label-success">4</span>
                        </a>
                        <ul class="dropdown-menu">
                            <li class="header">You have 4 messages</li>
                            <li>
                                <ul class="menu">
                                    <li>
                                        <a href="#">
                                            <div class="pull-left">
                                                <img src="<?php //echo base_url() ?>/public/admin/dist/img/dossali-logo.png"
                                                     class="img-circle"
                                                     alt="User Image">
                                            </div>
                                            <h4>
                                                Support Team
                                                <small><i class="fa fa-clock-o"></i> 5 mins</small>
                                            </h4>

                                        </a>
                                    </li>
                                </ul>
                            </li>
                            <li class="footer"><a href="#">See All Messages</a></li>
                        </ul>
                    </li>
                    <li class="dropdown notifications-menu">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                            <i class="fa fa-bell-o"></i>
                            <span class="label label-warning">10</span>
                        </a>
                        <ul class="dropdown-menu">
                            <li class="header">You have 10 notifications</li>
                            <li>
                                <ul class="menu">
                                    <li>
                                        <a href="#">
                                            <i class="fa fa-users text-aqua"></i> 5 new members joined today
                                        </a>
                                    </li>
                                </ul>
                            </li>
                            <li class="footer"><a href="#">View all</a></li>
                        </ul>
                    </li>
                    <li class="dropdown tasks-menu">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                            <i class="fa fa-flag-o"></i>
                            <span class="label label-danger">9</span>
                        </a>
                        <ul class="dropdown-menu">
                            <li class="header">You have 9 tasks</li>
                            <li>
                                <ul class="menu">
                                    <li>
                                        <a href="#">
                                            <h3>
                                                Design some buttons
                                                <small class="pull-right">20%</small>
                                            </h3>
                                            <div class="progress xs">
                                                <div class="progress-bar progress-bar-aqua" style="width: 20%"
                                                     role="progressbar" aria-valuenow="20" aria-valuemin="0"
                                                     aria-valuemax="100">
                                                    <span class="sr-only">20% Complete</span>
                                                </div>
                                            </div>
                                        </a>
                                    </li>
                                </ul>
                            </li>
                            <li class="footer">
                                <a href="#">View all tasks</a>
                            </li>
                        </ul>
                    </li>-->
                    <li class="dropdown user user-menu">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                            <img src="<?php echo base_url() ?>/public/admin/dist/img/logo.png"
                                 class="user-image"
                                 alt="User Image">
                            <span class="hidden-xs"><?= strtoupper($_SESSION['username']) ?></span>
                        </a>
                        <ul class="dropdown-menu">
                            <!-- User image -->
                            <li class="user-header">
                                <img src="<?php echo base_url() ?>/public/admin/dist/img/logo.png"
                                     class="img-circle"
                                     alt="User Image">
                                <p>
                                    Welcome, <b><?= $_SESSION['username'] ?></b>
                                </p>
                            </li>
                            <li class="user-footer">
                                <div class="pull-left">
                                    <a href="<?= site_url('Admin/reset_password') ?>" class="btn btn-default btn-flat">Change Password</a>
                                </div>
                                <div class="pull-right">
                                    <a href="<?= site_url('Admin/logout') ?>" class="btn btn-default btn-flat">Logout</a>
                                </div>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="#" data-toggle="control-sidebar"><i class="fa fa-gears"></i></a>
                    </li>
                    <li style="color: white;text-align: center;
                            font-family: 'Orbitron', sans-serif;
                            margin-top: 5px; font-size: medium"
                                id="date_part"></li>
                </ul>
            </div>
        </nav>
    </header>
    <aside class="main-sidebar">
        <section class="sidebar">
            <div class="user-panel">
                <div class="pull-left image">
                    <img src="<?php echo base_url() ?>/public/admin/dist/img/Admin.png" class="img-circle"
                         alt="User Image">
                </div>
                <div class="pull-left info">
                    <p><?= $_SESSION['username'] ?></p>
                    <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
                </div>
            </div>
            <ul class="sidebar-menu" data-widget="tree">
                <li>
                    <a href="">
                        <i class="fa fa-th"></i> <span>Widgets</span>
                        <span class="pull-right-container"></span>
                    </a>
                </li>
                <li class="treeview">
                    <a href="#">
                        <i class="glyphicon glyphicon-blackboard"></i>
                        <span>Dashboard</span>
                    </a>
                </li>
                <li class="treeview">
                    <a href="#">
                        <i class="fa fa-group"></i>
                        <span>Videos</span>
                        <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
                    </a>
                    <ul class="treeview-menu">
                        <li><a href="<?= site_url('Admin/add_video')?>"><i class="fa fa-circle-o"></i> Add Video</a></li>
                        <li><a href="<?= site_url('Admin/video')?>"><i class="fa fa-circle-o"></i> Videos List</a></li>
                    </ul>
                </li>
                <li class="treeview">
                    <a href="#">
                        <i class="fa fa-group"></i>
                        <span>Images</span>
                        <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
                    </a>
                    <ul class="treeview-menu">
                        <li><a href="<?= site_url('Admin/add_image')?>"><i class="fa fa-circle-o"></i> Add Image</a></li>
                        <li><a href="<?= site_url('Admin/Images')?>"><i class="fa fa-circle-o"></i> Images List</a></li>
                    </ul>
                </li>
<!--
                <li class="treeview">
                    <a href="#">
                        <i class="fa fa-group"></i>
                        <span>Users</span>
                        <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
                    </a>
                    <ul class="treeview-menu">
                        <li><a href="<?/*= site_url('Admin/add_service_provider')*/?>"><i class="fa fa-circle-o"></i> Add Service Provider </a></li>
                        <li><a href="<?/*= site_url('Admin/manage_service_provider')*/?>"><i class="fa fa-circle-o"></i> Manage Service Provider</a></li>
                        <li><a href="<?/*= site_url('Admin/manage_service_seeker')*/?>"><i class="fa fa-circle-o"></i> Manage Service Seeker</a></li>
                        <li><a href="<?/*= site_url('Admin/user_groups')*/?>"><i class="fa fa-circle-o"></i> User Groups</a></li>
                    </ul>
                </li>
                <li class="treeview">
                    <a href="#">
                        <i class="fa fa-bars"></i>
                        <span>Service Categories</span>
                        <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
                    </a>
                    <ul class="treeview-menu">
                        <li><a href=""><i class="fa fa-circle-o"></i> Add Category</a></li>
                        <li><a href=""><i class="fa fa-circle-o"></i> Manage Sub Category</a></li>
                        <li><a href=""><i class="fa fa-circle-o"></i> Manage Sub Sub Category</a></li>
                    </ul>
                </li>
                <li class="treeview">
                    <a href="#">
                        <i class="fa fa-history"></i>
                        <span>History</span>
                        <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
                    </a>
                    <ul class="treeview-menu">
                        <li><a href=""><i class="fa fa-circle-o"></i> Service Provider History</a></li>
                        <li><a href=""><i class="fa fa-circle-o"></i> Service Seeker History</a></li>
                    </ul>
                </li>
                <li class="treeview">
                    <a href="#">
                        <i class="fa fa-bullhorn"></i>
                        <span>Promotion</span>
                        <span class="pull-right-container">
            </span>
                    </a>
<!---</li>
-->
            </ul>
        </section>
        <!-- /.sidebar -->
    </aside>