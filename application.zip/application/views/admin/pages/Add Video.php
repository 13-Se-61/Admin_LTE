<?php
/**
 * Created by PhpStorm.
 * User: asad
 * Date: 11/6/2018
 * Time: 5:48 PM
 */?>
<div class="content-wrapper">
    <section class="content">
        <div class="row">
            <div class="col-md-6">
                <form action="<?= site_url('Admin/add_videos') ?>" class="dropzone" id="dropzoneForm"></form>
                <div align="center">
                <select id="country">
                    <option value=''></option>
                    </select>
                    <select id="region">
                    <option value=''></option>
                    </select>
                    <button type="button" class="btn btn-info" id="submit-all">Upload</button>
                </div>
                <div id="preview"></div>
            </div>
        </div>
    </section>
</div>