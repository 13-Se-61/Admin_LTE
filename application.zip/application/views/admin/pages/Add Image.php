<?php
/**
 * Created by PhpStorm.
 * User: asad
 * Date: 11/7/2018
 * Time: 11:52 AM
 */?>
<div class="content-wrapper">
    <section class="content">
        <div class="row">
            <div class="col-md-3">
                <form action="<?php echo site_url('Admin/add_pic');?>" method="post" enctype="multipart/form-data">
                    <div class="form-group">
                        <label for="exampleInputEmail1">Title</label>
                        <input type="text" class="form-control" name="title" placeholder="Title">
                    </div>
                    <div class="form-group">
                        <label for="exampleInputFile">File input</label>
                        <input type="file" class="dropify" name="pic" data-height="300">
                    </div>
                    <div><input type="submit" value="Submit" /></div>

                    <button type="submit" class="btn btn-primary">Upload</button>
                </form>
                <div id="preview"></div>
            </div>
        </div>
    </section>
</div>