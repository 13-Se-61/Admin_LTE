<div class="modal fade" id="delete_modal">
    <div class="modal-dialog modal-sm">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Delete Record</h4>
            </div>
            <div class="modal-body">
                <p>Do you really wish to delete this record?</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">No</button>
                <a id="delete_btn" id="modal-delete-button" class="btn btn-danger">Yes</a>
            </div>
        </div>
    </div>
</div>
<footer class="main-footer">
    <div class="pull-right hidden-xs">
        <b>Version</b> 1.0.0
    </div>
    <strong>Copyright &copy; <?= date('Y') ?> <a href="https://">Nested Logics PRIVATE LIMITED</a>.</strong> All rights
    reserved.
</footer>
<aside class="control-sidebar control-sidebar-dark">
    <ul class="nav nav-tabs nav-justified control-sidebar-tabs">
        <li><a href="#control-sidebar-home-tab" data-toggle="tab"><i class="fa fa-home"></i></a></li>
        <li><a href="#control-sidebar-settings-tab" data-toggle="tab"><i class="fa fa-gears"></i></a></li>
    </ul>
    <div class="tab-content">
        <div class="tab-pane" id="control-sidebar-home-tab">
            <h3 class="control-sidebar-heading">Recent Activity</h3>
            <ul class="control-sidebar-menu">
                <li>
                    <a href="javascript:void(0)">
                        <i class="menu-icon fa fa-birthday-cake bg-red"></i>
                        <div class="menu-info">
                            <h4 class="control-sidebar-subheading">Langdon's Birthday</h4>
                            <p>Will be 23 on April 24th</p>
                        </div>
                    </a>
                </li>
                <li>
                    <a href="javascript:void(0)">
                        <i class="menu-icon fa fa-user bg-yellow"></i>

                        <div class="menu-info">
                            <h4 class="control-sidebar-subheading">Frodo Updated His Profile</h4>

                            <p>New phone +1(800)555-1234</p>
                        </div>
                    </a>
                </li>
                <li>
                    <a href="javascript:void(0)">
                        <i class="menu-icon fa fa-envelope-o bg-light-blue"></i>

                        <div class="menu-info">
                            <h4 class="control-sidebar-subheading">Nora Joined Mailing List</h4>

                            <p>nora@example.com</p>
                        </div>
                    </a>
                </li>
                <li>
                    <a href="javascript:void(0)">
                        <i class="menu-icon fa fa-file-code-o bg-green"></i>

                        <div class="menu-info">
                            <h4 class="control-sidebar-subheading">Cron Job 254 Executed</h4>

                            <p>Execution time 5 seconds</p>
                        </div>
                    </a>
                </li>
            </ul>
            <h3 class="control-sidebar-heading">Tasks Progress</h3>
            <ul class="control-sidebar-menu">
                <li>
                    <a href="javascript:void(0)">
                        <h4 class="control-sidebar-subheading">
                            Custom Template Design
                            <span class="label label-danger pull-right">70%</span>
                        </h4>

                        <div class="progress progress-xxs">
                            <div class="progress-bar progress-bar-danger" style="width: 70%"></div>
                        </div>
                    </a>
                </li>
                <li>
                    <a href="javascript:void(0)">
                        <h4 class="control-sidebar-subheading">
                            Update Resume
                            <span class="label label-success pull-right">95%</span>
                        </h4>

                        <div class="progress progress-xxs">
                            <div class="progress-bar progress-bar-success" style="width: 95%"></div>
                        </div>
                    </a>
                </li>
                <li>
                    <a href="javascript:void(0)">
                        <h4 class="control-sidebar-subheading">
                            Laravel Integration
                            <span class="label label-warning pull-right">50%</span>
                        </h4>

                        <div class="progress progress-xxs">
                            <div class="progress-bar progress-bar-warning" style="width: 50%"></div>
                        </div>
                    </a>
                </li>
                <li>
                    <a href="javascript:void(0)">
                        <h4 class="control-sidebar-subheading">
                            Back End Framework
                            <span class="label label-primary pull-right">68%</span>
                        </h4>

                        <div class="progress progress-xxs">
                            <div class="progress-bar progress-bar-primary" style="width: 68%"></div>
                        </div>
                    </a>
                </li>
            </ul>
        </div>
        <div class="tab-pane" id="control-sidebar-stats-tab">Stats Tab Content</div>
        <div class="tab-pane" id="control-sidebar-settings-tab">
            <form method="post">
                <h3 class="control-sidebar-heading">General Settings</h3>

                <div class="form-group">
                    <label class="control-sidebar-subheading">
                        Report panel usage
                        <input type="checkbox" class="pull-right" checked>
                    </label>

                    <p>
                        Some information about this general settings option
                    </p>
                </div>
                <div class="form-group">
                    <label class="control-sidebar-subheading">
                        Allow mail redirect
                        <input type="checkbox" class="pull-right" checked>
                    </label>

                    <p>
                        Other sets of options are available
                    </p>
                </div>
                <div class="form-group">
                    <label class="control-sidebar-subheading">
                        Expose author name in posts
                        <input type="checkbox" class="pull-right" checked>
                    </label>

                    <p>
                        Allow the user to show his name in blog posts
                    </p>
                </div>
                <h3 class="control-sidebar-heading">Chat Settings</h3>

                <div class="form-group">
                    <label class="control-sidebar-subheading">
                        Show me as online
                        <input type="checkbox" class="pull-right" checked>
                    </label>
                </div>
                <div class="form-group">
                    <label class="control-sidebar-subheading">
                        Turn off notifications
                        <input type="checkbox" class="pull-right">
                    </label>
                </div>

                <div class="form-group">
                    <label class="control-sidebar-subheading">
                        Delete chat history
                        <a href="javascript:void(0)" class="text-red pull-right"><i class="fa fa-trash-o"></i></a>
                    </label>
                </div>
            </form>
        </div>
    </div>
</aside>
<div class="control-sidebar-bg"></div>
</div>
<script src="<?php echo base_url() ?>/public/admin/plugins/jquery/dist/jquery.min.js"></script>
<script src="<?php echo base_url() ?>/public/admin/plugins/bootstrap/dist/js/bootstrap.min.js"></script>
<script src="<?php echo base_url() ?>/public/admin/plugins/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url() ?>/public/admin/plugins/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
<script src="<?php echo base_url() ?>/public/admin/plugins/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<script src="<?php echo base_url() ?>/public/admin/plugins/fastclick/lib/fastclick.js"></script>
<script src="<?php echo base_url() ?>/public/admin/dist/js/adminlte.min.js"></script>
<script src="<?php echo base_url() ?>/public/admin/dist/js/demo.js"></script>
<script src="<?php echo base_url() ?>/public/admin/plugins/moment/min/moment.min.js"></script>
<script src="<?php echo base_url() ?>/public/admin/plugins/bootstrap-daterangepicker/daterangepicker.js"></script>
<script src="<?php echo base_url() ?>/public/admin/plugins/select2/dist/js/select2.full.min.js"></script>
<script src="<?php echo base_url() ?>/public/admin/plugins/toastr/toastr.min.js"></script>
<script src="<?php echo base_url() ?>/public/admin/plugins/dropzone/dropzone.js"></script>
<script>

    $(function () {

        $('#daterange-btn').daterangepicker(
            {
                ranges: {
                    'This Month': [moment().startOf('month'), moment().endOf('month')],
                    'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')],
                    'Last 7 Days': [moment().subtract(6, 'days'), moment()],
                    'Last 30 Days': [moment().subtract(29, 'days'), moment()]

                }
            },
            function (start, end) {
                $('#daterange-btn span').html('<i class="fa fa-calendar"></i> <b>' + start.format('DD-MM-YYYY') + '</b> - <b>' + end.format('DD-MM-YYYY') + '</b>');
                $('#date_range').val(start.format('DD-MM-YYYY') + ' - ' + end.format('DD-MM-YYYY'));
            }
        );
        $('.select2').select2();

        var interval = setInterval(function () {
            var momentNow = moment();
            $('#date_part').html(momentNow.format('DD-MM-YYYY  ')
                + '<br/>' + momentNow.format('hh:mm:ss A'));
        }, 100);
        toastr.options.progressBar = true;
        toastr.options.positionClass = "toast-bottom-right";
        toastr.success('This will be our message dialog!', 'CMA Goods')

        $('#dt_w_5_1').DataTable({
            'paging': true, "scrollX": true,
            'lengthChange': false,
            'searching': true,
            'ordering': true,
            'info': true,
            'autoWidth': true,
            'pageLength': 5
        });
        $('#dt_w_5_2').DataTable({
            'paging': true, "scrollX": true,

            'lengthChange': false,
            'searching': true,
            'ordering': true,
            'info': true,
            'autoWidth': true,
            'pageLength': 5
        });
        $('#dt_w_10_1').DataTable({
            'paging': false,
            'scrollX': true,
            'scrollY': true,
            'lengthChange': true,
            'searching': true,
            'ordering': false,
            'info': true,
            'autoWidth': true
        });
        $('#dt_w_10_2').DataTable({
            'paging': true,
            'scrollX': true,
            'scrollY': true,
            'lengthChange': true,
            'searching': true,
            'ordering': false,
            'info': true,
            'autoWidth': true
        });
        $('#create_employee_region').change(function () {
            $.ajax({
                dataType: 'json',
                url: '<?=site_url('app/ajax/get_region_code/')?>' + $('#create_employee_region').val(),
                success: function (response) {

                    $('#c_e_r_id').val(response.region_code);
                    $('#create_employee_id').val('Auto Assigned');
                },
                error: function () {
                    alert('An unexpected error occurred. Please contact dev support');
                }
            });
        });
        $('#create_employee_department').change(function () {
            $.ajax({
                dataType: 'json',
                url: '<?=site_url('app/ajax/get_department_code/')?>' + $('#create_employee_department').val(),
                success: function (response) {
                    $('#c_e_d_id').val(response.department_code)
                    $('#create_employee_id').val('<?=date('y')?>' + $('#c_e_r_id').val() + $('#c_e_d_id').val());
                },
                error: function () {
                    alert('An unexpected error occurred. Please contact dev support');
                }
            });
        });
        $('#create_user_employee_id').change(function () {
            $.ajax({
                dataType: 'json',
                url: '<?=site_url('app/ajax/get_employee_data/')?>' + $('#create_user_employee_id').val(),
                success: function (response) {
                    $('#create_user_username').val(response.code);
                    $('#create_user_email').val(response.email);
                    $('#create_user_region').val(response.region_id);

                },
                error: function () {
                    alert('An unexpected error occurred. Please contact dev support');
                }
            });
        });
        $('#create_employee_designation').change(function () {
            $.ajax({
                dataType: 'json',
                url: '<?=site_url('app/ajax/get_designation/')?>' + $('#create_employee_designation').val(),
                success: function (response) {
                    $('#create_employee_basic_salary').val(response.basic_salary);
                    $('#create_employee_allowances').val(response.allowances);
                    $('#create_employee_allowances_desc').val(response.allowances_description);

                },
                error: function () {
                    alert('An unexpected error occurred. Please contact dev support');
                }
            });
        });
    });
    function confirm_booking(booking_id) {
        $('#confirm_booking_btn').attr('href', '<?=site_url('app/bookings/confirm')?>' + '/' + booking_id);
        $('#confirm_booking_modal').modal('show');
    }
    function delete_region(region_id) {
        $('#delete_btn').attr('href', '<?=site_url('app/regions/delete')?>' + '/' + region_id);
        $('#delete_modal').modal('show');
    }
    function delete_designation(designation_id) {
        $('#delete_btn').attr('href', '<?=site_url('app/designations/delete')?>' + '/' + designation_id);
        $('#delete_modal').modal('show');
    }
    function delete_department(department_id) {
        $('#delete_btn').attr('href', '<?=site_url('app/departments/delete')?>' + '/' + department_id);
        $('#delete_modal').modal('show');
    }
</script>
</body>
</html>