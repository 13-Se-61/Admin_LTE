<?php
/**
 * Created by PhpStorm.
 * User: asad
 * Date: 11/6/2018
 * Time: 5:48 PM
 */?>
<div class="content-wrapper">
    <section class="content">
        <div class="row">
            <div class="col-md-6">
                <form action="<?= site_url('Admin/add_media') ?>" method="post" enctype="multipart/form-data">
<!--                    <iframe style="border: 3px solid #EEE;"
                            width="560" height="315"
                            src="5ac3c125a826f72db7a89d9d92e8f478.wmv"
                            frameborder="2" allowfullscreen></iframe>
                    <video width="320" height="240" autoplay>
                        <source src="movie.mp4" type="video/mp4">
                        <source src="movie.ogg" type="video/ogg">
                        Your browser does not support the video tag.
                    </video>
--><!--
                    <object width="400" height="50" data="bookmark.swf"></object>-->
                    <input type="file" name="media"/>
                    <input type="submit" name="upload" style="margin-top: 2%"/>
                </form>
                <frameset rows="20%,70%,30%">
                    //Frame 1
                    <frame src="">
                    //Frame 2
                    <frameset cols="50%,50%">
                        <frame src="">
                        <frame src="">
                    </frameset>
                    //Frame 3
                    <frame src="">
                </frameset>
            </div>
        </div>
    </section>
</div>