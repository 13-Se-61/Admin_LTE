<?php
/**
 * Created by PhpStorm.
 * User: asad
 * Date: 11/7/2018
 * Time: 12:54 PM
 */?>
<body
<!--<h3>Your file was successfully uploaded!</h3>
<ul>
    <?php /*foreach ($upload_data as $item => $value):*/?>
        <li><?php /*echo $item;*/?>: <?php /*echo $value;*/?></li>
    <?php /*endforeach; */?>
</ul>
<p><?php /*echo anchor('upload', 'Upload Another File!'); */?></p>
-->
<h3>Your file was successfully uploaded!</h3>
<ul>
    <?php foreach ($upload_data as $item => $value):?>
        <li><?php echo $item;?>: <?php echo $value;?></li>
    <?php endforeach; ?>
</ul>
<p><?php echo anchor('upload', 'Upload Another File!'); ?></p>
</body>