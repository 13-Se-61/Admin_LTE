<?php
/**
 * Created by PhpStorm.
 * User: asad
 * Date: 11/7/2018
 * Time: 11:52 AM
 */?>
<div class="content-wrapper">
    <section class="content">
        <div class="row">
            <div class="col-md-6">
                <form action="<?= site_url('Admin/add_pic') ?>" method="post" enctype="multipart/form-data">
                    <input type="file" name="pic"/>
                    <input type="submit"
                           naem="upload" style="margin-top: 2%"/>
                </form>
            </div>
        </div>
    </section>
</div>