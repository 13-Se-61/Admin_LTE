<?php
/**
 * Created by PhpStorm.
 * User: asad
 * Date: 11/6/2018
 * Time: 5:51 PM
 */?>

<div style="background: #fbf9ff; padding: 5%">
    <table id="myTable" class="table table-bordered table-striped">

        <thead>
        <tr>
            <th>Sr. No.</th>
            <th>Video Name</th>
            <th>Path</th>
            <th>Details</th>
        </tr>
        </thead>
        <?php foreach($data as $result){
        ?>
        <tbody>
        <tr>
            <a>
                <td><?= $result['id'];?></td>
                <td><?= $result['name'];?></td>
                <td><?= $result['url'];?></td>
                <td><a style="color:blue; data-toggle=modal";
                       href="#<?/*= site_url('Admin/show_images')*//**/?><!--/--><?/*= $result['s_id']; */?>">Details</a></td>
            </a>
        </tr>
        <?php
        }
        ?>
        </tbody>
    </table>
</div>