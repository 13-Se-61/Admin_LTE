<div class="content-wrapper">

    <section class="content">

        <div class="row">
            <div class="col-md-6">
                <div class="callout callout-info">
                    <h4>Tip!</h4>
                    <p>Please include a combination of Alphanumeric and Special characters to make the password
                        strong.</p>
                </div>
                Asad is Resetting Password!
                <form action="<?= site_url('Admin/change_password')?>" method="post">
                    <div class="box">
                        <div class="box-header with-border">
                            <h3 class="box-title">Change Password</h3>
                        </div>
                        <div class="box-body">
                            <?php
                            if ($this->session->flashdata('success_msg')):
                                echo "<div class='alert alert-success' role='alert'>" . $this->session->flashdata('success_msg') . "</div>";;
                            elseif (validation_errors()) :
                                echo "<div class='alert alert-danger' role='alert'>" . validation_errors() . "</div>";
                            endif;
                            ?>
                            <div class="form-group">
                                <label>Current Password</label>
                                <input type="password" name="current_password" class="form-control"
                                       placeholder="Enter Current Password" required="required">
                            </div>
                            <div class="form-group">
                                <label>New Password</label>
                                <input type="password" name="password" class="form-control"
                                       placeholder="Enter New Password" required="required">
                            </div>
                            <div class="form-group">
                                <label>Confirm Password</label>
                                <input type="password" name="confirm_password" class="form-control"
                                       placeholder="Confirm Password" required="required">
                            </div>

                        </div>
                        <div class="box-footer">
                            <div class="pull-right">
                                <button class="btn btn-primary btn-sm" type="submit">Update Password <i
                                            class="fa fa-chevron-right-o"></i></button>
                            </div>
                        </div>
                </form>
            </div>
        </div>
</div>
</section>
</div>