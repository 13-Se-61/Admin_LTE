<?php
class Admin extends CI_Controller{
    public  function __construct()
    {
        parent::__construct();
        $this->load->helper(array('form', 'url'));
        if (!isset($this->session->userdata['is_logged_in'])) {
            $this->logout();
        }
    }
    public  function index()
    {   $this->load->view('admin/includes/header', array(
            'title' => 'Dashboard'
        ));
        $this->load->view('admin/pages/index');
        $this->load->view('admin/includes/footer');
    }
    public  function settings($action = 'change_password')
    {
        if ($action == 'change-password') {
            $this->load->library('form_validation');
            $this->form_validation->set_rules('current_password', 'Current Password', 'required|callback_current_password_check');
            $this->form_validation->set_rules('password', 'Password', 'required|min_length[8]');
            $this->form_validation->set_rules('confirm_password', 'Confirm Password', 'required|matches[password]');
            if ($this->form_validation->run() === TRUE) {
                $this->load->model('Auth_model');
                $query = $this->Auth_model->update([
                    'password' => hash('sha256', $this->input->post('password'))
                ], $this->session->userdata('user_id'));
                if ($query) $this->session->set_flashdata('success_msg', '<i class="fa fa-check-circle-o"></i> Password updated successfully');
            }
            $this->load->view('admin/includes/header',array(
                'title' =>  'change Password'
            ));
            $this->load->view('admin/pages/settings/change_password');
            $this->load->view('admin/includes/footer');
        }
    }
    public  function change_password()
    {
            $this->load->library('form_validation');
            $this->form_validation->set_rules('current_password', 'Current Password', 'required|callback_current_password_check');
            $this->form_validation->set_rules('password', 'Password', 'required|min_length[8]');
            $this->form_validation->set_rules('confirm_password', 'Confirm Password', 'required|matches[password]');
            if ($this->form_validation->run()) {
                $this->load->model('Auth_model');
                $query = $this->Auth_model->update([
                    'password' => hash('sha256', $this->input->post('password'))
                ], $this->session->userdata('user_id'));
                if ($query) $this->session->set_flashdata('success_msg', '<i class="fa fa-check-circle-o"></i> Password updated successfully');
            }
            $this->load->view('admin/includes/header',array(
                'title' => 'Change Password'
            ));
            $this->load->view('admin/pages/Change Password');
            $this->load->view('admin/includes/footer');
    }
    public  function reset_password()
    {
        $this->load->view('admin/includes/header',array(
            'title' => 'Reset Password'
        ));
        $this->load->view('admin/pages/Change Password');
        $this->load->view('admin/includes/footer');
    }
    public  function video()
    {
        $this->load->model('Auth_model');
        $data= $this->Auth_model->show_videos();
        /*echo'<pre>';
        print_r($data);
        exit;*/
        $this->load->view('admin/includes/header',array(
            'title' => 'Videos'
        ));
        $this->load->view('admin/pages/Video',[
            'data' => $data ]);
        $this->load->view('admin/includes/footer');
    }
    public  function add_video()
    {
        $this->load->view('admin/includes/header',array(
            'title' => 'Add Video'
        ));
        $this->load->view('admin/pages/Add Video');
        $this->load->view('admin/includes/footer');
    }
    public  function images()
    {
        $this->load->model('Auth_model');
        $data= $this->Auth_model->show_images();
        $this->load->view('admin/includes/header',array(
            'title' => 'Images'
        ));
        $this->load->view('admin/pages/Images',[
            'data' => $data ]);
        $this->load->view('admin/includes/footer');
    }
    public  function add_pic()
    {
        if(!empty($_FILES['pic']['name'])){
            $image_name=$_FILES['pic']['name'];
            $picture = $this->upload_image('pic');
            if($picture['code'] == 200){
                $url=$picture['url'];
                echo 'The Image is Uploaded Successfully and Path is '.$url;
                $this->load->model('Auth_model');
                $data = array();
                $data['name'] = $image_name;
                $data['url'] = $url;
                $query= $this->Auth_model->upload_image($data);
                if($query){
                    echo '<br/>The Url is Saved in Database!';
                }
            }
        }
    }
    public  function add_image()
    {
        $this->load->view('admin/includes/header',array(
            'title' => 'Add Images'
        ));
        $this->load->view('admin/pages/Add Image');
        $this->load->view('admin/includes/footer');
    }
    public  function upload_image($name)
    {
        $config['upload_path'] = './uploads/';
        $config['allowed_types']        = 'jpeg|jpg|png|gif|JPEG|JPG|PNG|GIF';
        $config['encrypt_name']        	= true;
        $config['remove_spaces']        = true;
        $config['file_ext_tolower']     = true;
        $data['code'] = 200;
            $data['message'] = 'Image upload successfully';
            $data['error'] = '';
            $this->load->library('upload', $config);
           if ( ! $this->upload->do_upload($name)){
               $data['message'] = 'Image Not uploaded successfully';
               $data['code'] = 201;
               $data['error'] = $this->upload->display_errors();
               echo '<pre>';
               print_r($data);
               exit;
           }
           else
           {
               $data1 = $this->upload->data();
               $data['url'] = 'uploads/'.$data1['file_name'];
           }
        return $data;
    }
    public  function add_media()
    {
        if(!empty($_FILES['media']['name'])){
            $video_name=$_FILES['media']['name'];
            $video= $this->upload_local_video('media');
            if($video['code'] == 200){
                $url=$video['url'];
                echo 'The Video is Uploaded Successfully and Path is '.$url;
                $this->load->model('Auth_model');
                $data = array();
                $data['name'] = $video_name;
                $data['url'] = $url;
                $query=  $this->Auth_model->upload_video($data);
                if($query){
                    echo '<br/>The Url is Saved in Database!';
                }
            }
        }
        /*      $this->load->view('admin/includes/header',array(
                'title' => 'Add Videos'
            ));
            $this->load->view('admin/pages/Add Video');
            $this->load->view('admin/includes/footer');*/
        }
            public function upload_local_video($name){
            $response = array();
            $response['code'] = 200;
            $response['message'] = 'Video uploaded successfully!';
            $response['error'] = '';
            $response['url'] = '';
            $config['upload_path'] = './uploads/videos/';
            $config['allowed_types'] = 'avi|mp4|wmv|flv|mkv|AVI|MP4|FLV|MKV';
            $config['encrypt_name'] = true;
            $config['remove_spaces'] = true;
            $config['file_ext_tolower'] = true;
            $config['max_size'] = 0;
            $this->load->library('upload', $config);
            if ( ! $this->upload->do_upload($name))
            {
                $error = array('error' => $this->upload->display_errors());
                $response['code'] = 201;
                $response['message'] = 'Video not uploaded successfully!';
                $response['error'] = $error;
            }
            else
            {
                $data = $this->upload->data();
                $response['url'] = 'uploads/videos/'.$data['file_name'];
            }
            return $response;
        }
            public function password_check()
            {
                if (preg_match('#[0-9]#', $this->input->post('password')) && preg_match('#[a-zA-Z]#', $this->input->post('password'))) {
                    return TRUE;
                }
                $this->form_validation->set_message('password_check', '%s must be alphanumeric and contain at least 1 upper case letter.');
                return FALSE;
            }
            public function current_password_check()
            {
                $username = $this->session->userdata('username');
                $password = $this->input->post('current_password');
                $this->load->model('Auth_model');
                $query = $this->Auth_model->get([
                    'username' => $username,
                    'password' => hash('sha256', $password)
                ]);
                if ($query) {
                    return TRUE;
                }
                $this->form_validation->set_message('current_password_check', '%s is not valid.');
                return FALSE;
            }
            public function pass($pass)
            {
                echo hash('sha256', $pass);
            }
            public function log()
            {
                $this->output->enable_profiler(true);
                $this->load->view('admin/includes/header');
                $this->load->view('admin/includes/footer');
            }
            public function logout()
            {
                $this->session->sess_destroy();
                redirect(site_url());
            }
 }