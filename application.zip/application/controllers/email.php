<?php

/**
 * Created by PhpStorm.
 * User: asad
 * Date: 11/8/2018
 * Time: 10:58 AM
 */
class email extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
    }

    public function index()
    {
        $config = Array(
            'protocol' => 'smtp',
            'smtp-host' => 'ssl://smtp.googlemail.com',
            'smpt-port' => '465',
            'smtp-user' => 'masadullah61@gmail.com',
            'smtp-pass' => 'AsadUllah',
        );
        $this->load->library('email', $config);
        $this->email->set_newline("\r\n");
        $this->email->from('masadullah61@gmail.com', 'Muhammad Asad Ullah');
        $this->email->to('masadullah61@gmail.com');
        $this->email->subject('Muhammad Asad Ullah');
        $this->email->message('I am Fine  AlhamduLillah!');
        if ($this->load->email->send()) {
            echo 'The Message is Sent AlhamduLillah';
        } else {
            show_error($this->email->print_debugger());
        }

    }
}
