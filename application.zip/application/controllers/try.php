<?php
/**
 * Created by PhpStorm.
 * User: asad
 * Date: 11/6/2018
 * Time: 3:22 PM
 */

class Admin extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        if (!isset($this->session->userdata['is_logged_in'])) {
            $this->logout();
        }
    }
    public function index()
    {
        $this->load->view('admin/includes/header', array(
            'title' => 'Dashboard'
        ));
        $this->load->view('admin/pages/index');
        $this->load->view('admin/includes/footer');
    }
    public function add_service_provider()
    {
        $this->load->view('admin/includes/header', array(
            'title' => 'Dashboard'
        ));
        $this->load->view('admin/pages/Add Service Provider');
        $this->load->view('admin/includes/footer');
    }
    public function manage_service_provider()
    {
        $this->load->view('admin/includes/header', array(
            'title' => 'Dashboard'
        ));
        $this->load->view('admin/pages/Manage Service Provider');
        $this->load->view('admin/includes/footer');
    }
    public function manage_service_seeker()
    {
        $this->load->view('admin/includes/header', array(
            'title' => 'Dashboard'
        ));
        $this->load->view('admin/pages/Manage Service Seeker');
        $this->load->view('admin/includes/footer');
    }
    public function user_groups()
    {
        $this->load->view('admin/includes/header', array(
            'title' => 'Dashboard'
        ));
        $this->load->view('admin/pages/User Groups');
        $this->load->view('admin/includes/footer');
    }
    public function settings($action = 'change_password')
    {
        if ($action == 'change-password') {
            $this->load->library('form_validation');
            $this->form_validation->set_rules('current_password', 'Current Password', 'required|callback_current_password_check');
            $this->form_validation->set_rules('password', 'Password', 'required|min_length[8]');
            $this->form_validation->set_rules('confirm_password', 'Confirm Password', 'required|matches[password]');
            if ($this->form_validation->run()) {
                $this->load->model('Auth_model');
                $query = $this->Auth_model->update([
                    'password' => hash('sha256', $this->input->post('password'))
                ], $this->session->user_data['userdata']['user_id']);
                if ($query) $this->session->set_flashdata('success_msg', '<i class="fa fa-check-circle-o"></i> Password updated successfully');
            }
            $this->load->view('admin/includes/header');
            $this->load->view('admin/pages/settings/change_password');
            $this->load->view('admin/includes/footer');
        }
    }
    public function change_password()
    {
        $this->load->library('form_validation');
        $this->form_validation->set_rules('current_password', 'Current Password', 'required|callback_current_password_check');
        $this->form_validation->set_rules('password', 'Password', 'required|min_length[8]');
        $this->form_validation->set_rules('confirm_password', 'Confirm Password', 'required|matches[password]');
        if ($this->form_validation->run()) {
            $this->load->model('Auth_model');
            $query = $this->Auth_model->update([
                'password' => hash('sha256', $this->input->post('password'))
            ], $this->session->user_data['userdata']['user_id']);
            if ($query) $this->session->set_flashdata('success_msg', '<i class="fa fa-check-circle-o"></i> Password updated successfully');
        }
        $this->load->view('admin/includes/header');
        $this->load->view('admin/pages/index');
        $this->load->view('admin/includes/footer');
    }
    public function reset_password()
    {
        $this->load->view('admin/includes/header');
        $this->load->view('admin/pages/Change Password');
        $this->load->view('admin/includes/footer');
    }
    public function password_check()
    {
        if (preg_match('#[0-9]#', $this->input->post('password')) && preg_match('#[a-zA-Z]#', $this->input->post('password'))) {
            return TRUE;
        }
        $this->form_validation->set_message('password_check', '%s must be alphanumeric and contain at least 1 upper case letter.');
        return FALSE;
    }
    public function current_password_check()
    {
        $username = $this->session->userdata['userdata']['username'];
        $password = $this->input->post('current_password');
        $this->load->model('Auth_model');
        $query = $this->Auth_model->get([
            'username' => $username,
            'password' => hash('sha256', $password)
        ]);
        if ($query) {
            return TRUE;
        }
        $this->form_validation->set_message('current_password_check', '%s is not valid.');
        return FALSE;
    }
    public function pass($pass)
    {
        echo hash('sha256', $pass);
    }
    public function log()
    {
        $this->output->enable_profiler(true);
        $this->load->view('admin/includes/header');
        $this->load->view('admin/includes/footer');
    }
    public function logout()
    {
        $this->session->sess_destroy();
        redirect(site_url());
    }
}
