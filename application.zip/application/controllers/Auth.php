<?php
 class Auth extends CI_Controller{
    public function __construct(){
        parent::__construct();
        if (isset($this->session->userdata['is_logged_in'])){
            redirect(site_url($_SESSION['user_data']['role']));
        }
    }
    public function login(){
        $this->load->library('form_validation');
        $username = $this->input->post('username');
        $password = $this->input->post('password');
        $this->form_validation->set_rules('username', 'Username', 'required');
        $this->form_validation->set_rules('password', 'credentials', 'required|callback_login_check');
        if ($this->form_validation->run()) {
            $this->load->model('Auth_model');
            $query = $this->Auth_model->get([
                'username' => $username,
                'password' => hash('sha256', $password)
            ]);
            unset($query[0]['password']);
            $this->session->set_userdata('is_logged_in', 1);
            $this->session->set_userdata('username', $query[0]['username']);
            $this->session->set_userdata('user_id', $query[0]['user_id']);
            redirect(site_url( $query[0]['role']));
        }
            else {
                    $this->load->view('auth/login',array
                    (
                        'title'=>'Login',
                        'h1'=>'Admin',
                        'h2'=>'LTE'
                    ));
        }
    }
    function login_check(){

        $username = $this->input->post('username');
        $password = $this->input->post('password');
        $this->load->model('Auth_model');
        $query = $this->Auth_model->get([
            'username' => $username,
            'password' => hash('sha256', $password)
        ]);
        if ($query){
            echo'Query Running';
            return TRUE;
        }
        else {
            echo'Query not Running';
            $this->form_validation->set_message('login_check', 'Invalid %s');
            return FALSE;
        }
    }
    public function password($pass){
        echo hash('sha256', $pass);
    }
 }